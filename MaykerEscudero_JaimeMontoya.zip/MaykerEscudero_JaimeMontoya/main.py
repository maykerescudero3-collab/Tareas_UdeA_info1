#Importación de las funciones
import src.triqui as tr

#Importación de comandos
import src.utils.comandos as com
import src.utils.statistics as st
#Import libreria
import time

#Lista para el tablero
boarOrigin = [' ', ' ', ' ', ' ', ' ', ' ', ' ' ,' ', ' ']
board = boarOrigin.copy()
stat = ['', 0, 0, 0]

#Desea jugar?
resp = "S"

# 1. Mostrar mensaje de bienvenida
tr.printIntro("assets/files/intro.txt")

#Organizamos la terminal
print("")
print(com.MU)

#Definimos algunas variable
ani = True #Activador de animación de jugar otra vez
jugadorWin = 0 #Veces ganadas del jugador
computadoraWin = 0 #Veces ganadas del computador
empates = 0 #Empates
veces = 0 #Veces que se juega

#Pedimos el nombre y lo guardamos
nombre = input("Nombre usuario: ")
stat[0] = nombre

#While para jugar
while resp.upper() == "S":
    #Se centan las jugadas
    veces += 1
    
    #Animación si se desea volver a jugar
    if not ani:
        print("\033[45F", end="")
        print(com.BORRAR)
        tr.printIntro("assets/files/intro.txt")
        print("")
        print("")
        print(f"Hola {nombre}, elige un simbolo")
        
    # 2. El usuario debe seleccionar la marca
    symbol = tr.inputPlayerLetter()
    
    # 3. Crear el tablero
    tr.drawBoard(boarOrigin)
    
    # 4. Quién va primero el usuario o la computadora?
    turn = tr.whoGoesFirst()
    
    #Colores dependiendo de quien va ganando
    if jugadorWin == computadoraWin:
        colorN = com.CYAN
        colorC = com.CYAN
    elif jugadorWin > computadoraWin:
        colorN = com.GREEN
        colorC = com.RED
    elif jugadorWin < computadoraWin:
        colorN = com.RED
        colorC = com.GREEN
    
        
        
    #Indicaciones del tablero
    print("")
    print("")
    print("")
    print("     -----------       use el tablero")
    print("     --Tablero--             del     ")
    print("     -----------           teclado   ")
    print("      7 | 8 | 9 ")
    print(f"     ---+---+---     {colorN}{nombre} = {jugadorWin}{com.NORMAL}             ")
    print(f"      4 | 5 | 6      {colorC}computadora = {computadoraWin}{com.NORMAL}         ")
    print(f"     ---+---+---     {com.BLACK}Empates = {empates}{com.NORMAL}             ")
    print("      1 | 2 | 3 ")
    
    
    
    playing = True # El juego ha iniciado
    #Jugando
    while playing:
        
        #Variables de victoria
        winN = False #Boton de que gano el jugador
        winC = False #Boton de que gano el computador
        empate = False #Boton de empate
        
        if turn == 'Usuario': #5. Truno del usuario
            print(com.OC, end="")
            
            #Symbolo del usuario
            print("\033[10F", end="")
            
            #Texto segun el symbolo
            if tr.symbol[0] == "X":
                print(com.DELETE, end="")
                print(f"{com.RED}Tu turno X {nombre} X{com.NORMAL}")
            else:
                print(com.DELETE, end="")
                print(f"{com.BLUE}Turno de: O {nombre} O{com.NORMAL}") 
            print("\033[9E", end="")

            #Pedir jugada al usuario
            print(com.MU, end="")
            move = 0
            move = tr.getPlayerMove(board, move)
            
            #Actualizar el tablero
            tr.makeMove(board, tr.symbol[0], move - 1)
            
            #Organizar para pedirlo de nuevo
            print("\033[23A", end="")
            tr.drawBoard(board)
            print("\033[11B", end="")
            print(com.BORRAR, end="")
            
            #Verificar si el usuario ha ganado el juego.
            if tr.isWinner(board, tr.symbol[0]):
                stat[1] += 1
                jugadorWin += 1
                print(f"{com.GREEN}-----------------{nombre} ha ganado-----------------")
                print(f"-----------------Juego finalizado-----------------{com.NORMAL}")
                winN = True
                playing = False

            #Verificar si hay empate.
            if tr.isBoardFull(board):
                stat[3] += 1
                empates += 1
                print(f"{com.GREEN}-----------------Juego en empate-----------------")
                print(f"-----------------Juego finalizado----------------{com.NORMAL}")
                empate = True
                playing = False
            
            #Turno del computador
            turn = 'Computadora'

        else: # 6. Turno de la computadora.
            
            #Turno de la computadora
            print(com.OC)
            print("\033[11F", end="")
            
            #Texto segun el simbolo
            if tr.symbol[1] == "X":
                print(com.DELETE, end="")
                print(f"{com.RED}Turno de X la computadora X{com.NORMAL}")
            else:
                print(com.DELETE, end="")
                print(f"{com.BLUE}Turno de O la coputadora O{com.NORMAL}")
            print("\033[9E", end="")
            
            time.sleep(1.2) #Para imitar el pensamiento
            
            #Computadora hace jugada. 
            move = tr.getComputerMove(board, f"{symbol[1]}")
            tr.makeMove(board, tr.symbol[1], move)
            
            #Actualizar el tablero.
            print("\033[22A", end="")
            tr.drawBoard(board)
            print("\033[11B", end="")

            #Verificar si la computadora ha ganado el juego.
            if tr.isWinner(board, tr.symbol[1]):
                stat[2] += 1
                computadoraWin += 1
                print(f"{com.RED}--------------Computador ha ganado--------------")
                print(f"-----------------Juego finalizado-----------------{com.NORMAL}")
                winC = True
                playing = False

            #Verificar si hay empate.
            if tr.isBoardFull(board):
                stat[3] += 1
                empates += 1
                print(f"{com.GREEN}-----------------Juego en empate-----------------")
                print(f"-----------------Juego finalizado----------------{com.NORMAL}")
                empate = True
                playing = False

            #Turno del usuario
            turn = 'Usuario'

    # 7. Preguntar si el usuario quiere jugar una vez más
    #Color dependiendo de quien gane  
    if winN:
        colorW = com.GREEN
    if winC:
        colorW = com.RED
    if empate:
        colorW = com.CYAN
    
    #Preguntar si desea jugar denuevo
    print(colorW, end="")
    resp = input("¿Desea continuar jugando? [S/?]: ").upper()
    print(com.NORMAL)
    
    #Si si
    if resp == "S":
        ani = False
        tr.symbol.clear()
        board = boarOrigin.copy()
    #Si no
    else:
        with open("assets/files/Gracias.txt", encoding='utf-8') as gracias:
            adios = gracias.read()
        print(com.CYAN, adios, com.NORMAL)
        print(f"Tus puntos: {com.GREEN}{jugadorWin}{com.NORMAL}")
        print(f"Puntos del computador: {com.BLUE}{computadoraWin}{com.NORMAL}")
        print(f"Veces empatadas: {com.BLUE}{empates}{com.NORMAL}")
        print("-------------------------------------------------")
        print("-------------------------------------------------")
        print(f"Veces jugadas: {com.YELLOW}{veces}{com.NORMAL}")
        print("-------------------------------------------------")
        print("Puedes revisar la carpeta log para ver el registro")

st.statistics(stat)
print("\n")