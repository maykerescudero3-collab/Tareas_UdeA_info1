#Librerias importada
import random #Libreria Que te da números random
import time #Libreria de tiempo

#Carpetas importadas
import src.utils.comandos as com #Lista de comandos

#Lista para determinar el simbolo del jugador
symbol = []

def printIntro(introFile) -> None: #Función de bienvenida=
    #-------------------------------------
    #introFile: El archivo a abrir
    #-------------------------------------
    
    #Se abre el archivo y se lee
    with open(introFile, encoding='utf-8') as fr:
        lineas = fr.readlines()
    print("\n")
    
    #Se organiza la terminal para la información
    print(com.OC)
    time.sleep(0.1)
    
    #Ciclo para determinar cuantas veces se ejecuta la animación
    for i in range(2):
        
        #Cyan
        for linea in lineas:
            for car in linea:
                print(f"{com.CYAN}{car}", end="")
                time.sleep(0.0001)
        print(com.DOA)
        
        #Blue
        for linea in lineas:
            for car in linea:
                print(f"{com.BLUE}{car}", end="")
                time.sleep(0.0001)
        print(com.DOA)
        
        #Magenta
        for linea in lineas:
            for car in linea:
                print(f"{com.MAGENTA}{car}{com.NORMAL}", end="")
                time.sleep(0.0001)

        print(com.DOA)
        
    #Original
    for linea in lineas:
        for car in linea:
            print(car, end="")
            time.sleep(0.0005)

def drawBoard(board) -> None: #Función que imprime el tablero
    #----------------- 
    #board: El tablero
    #-----------------
    
    #Nuevo Tablero
    new_board = []
    
    #Le ponemos color a las marcas
    for mark in board:
        if mark == 'X':
            new_board.append(f"{com.RED}X{com.NORMAL}")
        elif mark == 'O':
            new_board.append(f"{com.BLUE}O{com.NORMAL}")
        else:
            new_board.append(" ")

    #Ponemos variables a las listas para comodidad
    a, b, c, d, e, f, g, h, i = new_board
    
    #Dibujamos el tablero
    print(com.NORMAL, end="")
    print("       |       |       ")
    print(f"   {g}   |   {h}   |   {i}   ")
    print("       |       |       ")
    print("-------+-------+-------")
    print("       |       |       ")
    print(f"   {d}   |   {e}   |   {f}   ")
    print("       |       |       ")
    print("-------+-------+-------")
    print("       |       |       ")
    print(f"   {a}   |   {b}   |   {c}   ")
    print("       |       |       ")

def inputPlayerLetter() -> list: #Función donde el jugador elije entre la X o O
    
    #Funcion resumida de animación
    def animacion():
        
        #se abre el archivo
        with open("assets/files/intro.txt", encoding='utf-8') as fr:
            lineas = fr.readlines()
        
        #Organizamos la terminal
        print("\n")
        print(com.OC)
        
        #Empieza la animación por dos ciclos
        for i in range(2):
            
            #Cyan
            for linea in lineas:
                for car in linea:
                    print(f"{com.CYAN}{car}", end="")
                    time.sleep(0.0001)
            print(com.DOA)
            
            #Blue
            for linea in lineas:
                for car in linea:
                    print(f"{com.BLUE}{car}", end="")
                    time.sleep(0.0001)
            print(com.DOA)
            
            #Magenta
            for linea in lineas:
                for car in linea:
                    print(f"{com.MAGENTA}{car}", end="")
                    time.sleep(0.0001)
            print(com.DOA)
        print(com.BORRAR)
        
        

    sw = True #Boton para el while (en especial el Else)
    
    while sw:
        print(com.MU, end="") #para mostrar el cursor
        
        #Pregunta cual simbolo elige
        elec = input("Ingrese con cual simbolo iniciara (x/o): ").upper()
        
        #Subimos (para la animación)
        print("\033[24A", end="")
        
        #eleción
        
        #Si es X
        if elec == "X":
            print(com.OC, end="")
            
            #animacion
            animacion()
            
            #Pantlla de eleccion X
            print(f"{com.RED} -------Eres la X-------")
            
            #Se organizan y se guardan los datos       
            print("\n")
            symbol.append("X")
            symbol.append("O")
            sw = False
        
        #Si es O
        elif elec == "O":
            print(com.OC, end="")
            
            #animacion
            animacion()
            
            #Pantalla de elección O
            print(f"{com.BLUE} -------Eres la O-------")
            
            #Se organizan y se guardan los datos
            print("\n")
            symbol.append("O")
            symbol.append("X")
            sw = False

        #En caso de no poner ni x ni o
        else:
            print("\033[2B")
            print(com.OC, end="")
            
            #leemos el texto
            with open("assets/files/intro.txt", encoding='utf-8') as it:
                lineas = it.read()
            
            #Animación de error
            for i in range(0, 2):
                
                #Red
                for linea in lineas:
                    for car in linea:
                        print(f"{com.RED}{car}{com.NORMAL}", end="")
                        time.sleep(0.0001)
                print(com.DOA)
                
                #Normal
                for linea in lineas:
                    for car in linea:
                        print(car, end="")
                        time.sleep(0.0001)
                print(com.DOA)
            
            #Mensaje de advertencia
            print("\033[18B", end="")
            print(f"{com.YELLOW}Debe de elegir ente X o O{com.BLACK}")

            #Borrar la línea anterior
            print("\033[1B", end="")
            print(com.BORRAR, end="")
        
    return symbol

def whoGoesFirst() -> str: #Función que escoge de forma aleatoria quein empieza
    
    #Variable para un numero random entre 1 y 2
    rand = random.randint(1, 2)
    
    #Devolvemos lo que salga
    return "Usuario" if rand == 1 else "Computadora"
    
def makeMove(board, letter, move) -> None: #Función que acctualiza el tablero
    #--------------------------------------------------
    #board: Tablero
    #letter: Marca del jugador
    #move: Número de la casilla en el que se desea poner
    #--------------------------------------------------
    
    board[move] = letter
    
def isWinner(board, letter) -> bool: #Función que determinar si gano
    #-------------------------
    #board: Tablero
    #letter: Marca a verificar
    #-------------------------
    
    #Verificamos filas
    if f"{letter}" == board[0] == board[1] == board[2]:
        return True
    elif f"{letter}" == board[3] == board[4] == board[5]:
        return True
    elif f"{letter}" == board[6] == board[7] == board[8]:
        return True
    
    # Verificar columnas
    elif f"{letter}" == board[0] == board[3] == board[6]:
        return True
    elif f"{letter}" == board[1] == board[4] == board[7]:
        return True
    elif f"{letter}" == board[2] == board[5] == board[8]:
        return True
    
    # Verificar diagonales
    elif f"{letter}" == board[2] == board[4] == board[6]:
        return True
    elif f"{letter}" == board[0] == board[4] == board[8]:
        return True
    
    else:
        return False

def isSpaceFree(board, move) -> bool: #Función que devuelve si hay o no espacio vacío
    #-----------------------------
    #board: Tablero
    #move: Movimiento de "x" o "O"
    #-----------------------------
    
    return True if board[move] == ' ' else False
    
def getPlayerMove(board, move) -> int:#Función para el movimiento del jugador
    #----------------------------
    #board: Tablero
    #move: Movimiento del jugador
    #----------------------------
    
    #Ciclo para que se repita en caso de ponerlo mal
    while True:
        
        #Se pide el movimiento
        print(com.MU, end="")
        move = input("elija su movimiento: ")
        
        #Verificamos si puso algo
        if move == "":
            #Animación de error
            print("\033[1A", end="")
            print(com.BORRAR, end="")
            print(com.RED, "elija su movimiento: ", com.NORMAL)
            time.sleep(0.5)
            print("\033[1A", end="")
            print(com.BORRAR, end="")
        
        #Verificar que sea un número
        elif move in "1234567890":
            
            #Lo cambiamos a entero
            move = int(move)
            
            #verificamos que este entre 1 y 9, además de si hay un espacio vacío
            if 1 <= move <= 9:
                if isSpaceFree(board, move - 1):
                    #Ropemos si si es así
                    break
                else:
                    #Animación de error
                    print("\033[1A", end="")
                    print(com.BORRAR, end="")
                    print(com.RED, "elija su movimiento: ", com.NORMAL)
                    time.sleep(0.5)
                    print("\033[1A", end="")
                    print(com.BORRAR, end="")
            else:
                #Animación de error
                print("\033[1A", end="")
                print(com.BORRAR, end="")
                print(com.RED, "elija su movimiento: ", com.NORMAL)
                time.sleep(0.5)
                print("\033[1A", end="")
                print(com.BORRAR, end="")

        #Si se pone una letra o simbolo diferente a un numero
        else:
            
            #Animación de error
            print("\033[1A", end="")
            print(com.BORRAR, end="")
            print(com.RED, "elija su movimiento: ", com.NORMAL)
            time.sleep(0.5)
            print("\033[1A", end="")
            print(com.BORRAR, end="")
            
    return move

def chooseRandomMoveFromList(board, movesList): #Función que escoge una casilla vacía del tablero
    #--------------------------------------------------------
    #board: Tablero
    #movesList: Movimiento random de la lista si hay un vació
    #--------------------------------------------------------

    i = 0
    cellRand = -1
    while i < len(board):
        j = 0
        while j < len(movesList):
            if not isSpaceFree(board, movesList[j]):
                movesList.pop(j)
            else:
                j += 1
        i += 1
    if len(movesList) > 0:
        cellRand = random.choice(movesList)
    return cellRand

def getComputerMove(board, computerLetter) -> int: #Función para el movimiento de la computadora
    #---------------------------------------
    #board: Tablero
    #computerLetter: Letra de la computadora
    #---------------------------------------
    
    freeSide = []

    # 1. Verificar si la computadora puede ganar...
    # Filas
    # Tercera fila
    if (computerLetter == board[0] == board[1]) and isSpaceFree(board, 2):
        cell = 2
    elif (computerLetter == board[0] == board[2]) and isSpaceFree(board, 1):
        cell = 1
    elif (computerLetter == board[1] == board[2]) and isSpaceFree(board, 0):
        cell = 0
    # Segunda fila
    elif (computerLetter == board[3] == board[4]) and isSpaceFree(board, 5):
        cell = 5
    elif (computerLetter == board[3] == board[5]) and isSpaceFree(board, 4):
        cell = 4
    elif (computerLetter == board[4] == board[5]) and isSpaceFree(board, 3):
        cell = 3
    # Primera fila
    elif (computerLetter == board[6] == board[7]) and isSpaceFree(board, 8):
        cell = 8
    elif (computerLetter == board[6] == board[8]) and isSpaceFree(board, 7):
        cell = 7
    elif (computerLetter == board[7] == board[8]) and isSpaceFree(board, 6):
        cell = 6

    # Columnas
    # Primera columna
    elif (computerLetter == board[0] == board[3]) and isSpaceFree(board, 6):
        cell = 6
    elif (computerLetter == board[0] == board[6]) and isSpaceFree(board, 3):
        cell = 3
    elif (computerLetter == board[3] == board[6]) and isSpaceFree(board, 0):
        cell = 0
    # Segunda columna
    elif (computerLetter == board[1] == board[4]) and isSpaceFree(board, 7):
        cell = 7
    elif (computerLetter == board[1] == board[7]) and isSpaceFree(board, 4):
        cell = 4
    elif (computerLetter == board[4] == board[7]) and isSpaceFree(board, 1):
        cell = 1
    # Tercera columna
    elif (computerLetter == board[2] == board[5]) and isSpaceFree(board, 8):
        cell = 8
    elif (computerLetter == board[2] == board[8]) and isSpaceFree(board, 5):
        cell = 5
    elif (computerLetter == board[5] == board[8]) and isSpaceFree(board, 2):
        cell = 2
        
    # Diagonales
    # Diagonal principal
    elif (computerLetter == board[2] == board[4]) and isSpaceFree(board, 6):
        cell = 6
    elif (computerLetter == board[2] == board[6]) and isSpaceFree(board, 4):
        cell = 4
    elif (computerLetter == board[4] == board[6]) and isSpaceFree(board, 2):
        cell = 2
    # Diagonal secundaria
    elif (computerLetter == board[0] == board[4]) and isSpaceFree(board, 8):
        cell = 8
    elif (computerLetter == board[0] == board[8]) and isSpaceFree(board, 4):
        cell = 4
    elif (computerLetter == board[4] == board[8]) and isSpaceFree(board, 0):
        cell = 0


    # 2. Si no, verificar si el usuario puede ganar en la siguiente jugada, si si, bloquear esta jugada...

    # Validación inicial para evitar el encierro desde el inicio
    
    elif (f"{symbol[0]}" == board[0] == board[8] or \
          f"{symbol[0]}" == board[2] == board[6]) and \
            board[4] == computerLetter and \
            board.count(f"{symbol[0]}") == 2 and \
            board.count(computerLetter) == 1:
        if isSpaceFree(board, 1):
            freeSide.append(1)
        if isSpaceFree(board, 3):
            freeSide.append(3)
        if isSpaceFree(board, 5):
            freeSide.append(5)
        if isSpaceFree(board, 7):
            freeSide.append(7)
        cell = random.choice(freeSide)
    
    # Filas
    # Primera fila
    elif (f"{symbol[0]}" == board[0] == board[1]) and isSpaceFree(board, 2):
        cell = 2
    elif (f"{symbol[0]}" == board[0] == board[2]) and isSpaceFree(board, 1):
        cell = 1
    elif (f"{symbol[0]}" == board[1] == board[2]) and isSpaceFree(board, 0):
        cell = 0
    # Segunda fila
    elif (f"{symbol[0]}" == board[3] == board[4]) and isSpaceFree(board, 5):
        cell = 5
    elif (f"{symbol[0]}" == board[3] == board[5]) and isSpaceFree(board, 4):
        cell = 4
    elif (f"{symbol[0]}" == board[4] == board[5]) and isSpaceFree(board, 3):
        cell = 3
    # Tercera fila
    elif (f"{symbol[0]}" == board[6] == board[7]) and isSpaceFree(board, 8):
        cell = 8
    elif (f"{symbol[0]}" == board[6] == board[8]) and isSpaceFree(board, 7):
        cell = 7
    elif (f"{symbol[0]}" == board[7] == board[8]) and isSpaceFree(board, 6):
        cell = 6

    # Columnas
    # Primera columna
    elif (f"{symbol[0]}" == board[0] == board[3]) and isSpaceFree(board, 6):
        cell = 6
    elif (f"{symbol[0]}" == board[0] == board[6]) and isSpaceFree(board, 3):
        cell = 3
    elif (f"{symbol[0]}" == board[3] == board[6]) and isSpaceFree(board, 0):
        cell = 0
    # Segunda columna
    elif (f"{symbol[0]}" == board[1] == board[4]) and isSpaceFree(board, 7):
        cell = 7
    elif (f"{symbol[0]}" == board[1] == board[7]) and isSpaceFree(board, 4):
        cell = 4
    elif (f"{symbol[0]}" == board[4] == board[7]) and isSpaceFree(board, 1):
        cell = 1
    # Tercera columna
    elif (f"{symbol[0]}" == board[2] == board[5]) and isSpaceFree(board, 8):
        cell = 8
    elif (f"{symbol[0]}" == board[2] == board[8]) and isSpaceFree(board, 5):
        cell = 5
    elif (f"{symbol[0]}" == board[5] == board[8]) and isSpaceFree(board, 2):
        cell = 2
        
    # Diagonales
    # Diagonal principal
    elif (f"{symbol[0]}" == board[2] == board[4]) and isSpaceFree(board, 6):
        cell = 6
    elif (f"{symbol[0]}" == board[2] == board[6]) and isSpaceFree(board, 4):
        cell = 4
    elif (f"{symbol[0]}" == board[4] == board[6]) and isSpaceFree(board, 2):
        cell = 2
    # Diagonal secundaria
    elif (f"{symbol[0]}" == board[0] == board[4]) and isSpaceFree(board, 8):
        cell = 8
    elif (f"{symbol[0]}" == board[0] == board[8]) and isSpaceFree(board, 4):
        cell = 4
    elif (f"{symbol[0]}" == board[4] == board[8]) and isSpaceFree(board, 0):
        cell = 0

    elif board.count(f"{symbol[0]}") == 1 and board.count(computerLetter) == 0 \
          and  f"{symbol[0]}" in [board[0], board[2], board[6], board[8]]:
        cell = 4

    elif board.count(f"{symbol[0]}") == 1 \
              and  f"{symbol[0]}" in [board[1], board[3], board[5], board[7]]:
            cell = 4

    elif f"{symbol[0]}" in [board[7], board[3]] and isSpaceFree(board, 6):
        cell = 6
    elif f"{symbol[0]}" in [board[1], board[3]] and isSpaceFree(board, 0):
        cell = 0
    elif f"{symbol[0]}" in [board[6], board[5]] and isSpaceFree(board, 2):
        cell = 2
    elif f"{symbol[0]}" in [board[5], board[7]] and isSpaceFree(board, 8):
        cell = 8

    # 3. Si no, tratar de poner una marca en alguna de las esquinas, si alguna está vacía...
    # 4. Si no, tratar de marcar la casilla del centro, si esta está vacía...
    # 5. Si no, tratar de poner una marca en alguna de las casillas de los lados...
    else:
        cell = chooseRandomMoveFromList(board, [0, 2, 6, 8])
        if cell == -1:
            cell = 4
            if not isSpaceFree(board, cell):
                cell = chooseRandomMoveFromList(board, [1, 3, 5, 7])            
    return cell

def isBoardFull(board) -> bool: #Función que verifica si hay o no empate
    #--------------
    #board: Tablero
    #--------------
    
    #Devuelve si hay empate o no
    return board.count(' ') == 0
