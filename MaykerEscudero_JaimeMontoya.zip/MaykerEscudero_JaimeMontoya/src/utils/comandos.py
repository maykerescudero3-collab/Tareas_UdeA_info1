#colores
NORMAL = '\033[0m' 
BLACK = '\033[30m' 
RED = '\033[31m' 
GREEN = '\033[32m'
BLUE = '\033[34m' 
YELLOW = '\033[33m' 
MAGENTA = '\033[35m'
CYAN = '\033[36m' 

#Moverse por la terminal
DOA = '\033[18A'#DOA = 18 Arriba

#cursor
OC = '\033[?25l'#oculta
MU = '\033[?25h'#Muestra
BORRAR = '\033[0J' #Borra todo
DELETE = '\033[0K' #Borra la línea