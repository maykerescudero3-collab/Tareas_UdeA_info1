from datetime import datetime

def statistics(stat) -> None:
    textEstat = ""
    textEstat += "-" * 20 + "Triqui" + "-" * 20 + "\n"

    now = datetime.now()
    textEstat += now.strftime("%A, %B %d, %Y - %H:%M:%S")
    
    textEstat += "\n\nNombre del jugador: " + stat[0] 

    textEstat += "\n\nJuegos ganados por el usuario: " + str(stat[1])
    textEstat += "\nJuegos ganados por el computador: " + str(stat[2]) 
    textEstat += "\nJuegos empatados: " + str(stat[3]) 
    textEstat += "\n" 
    textEstat += "-" * 46
    textEstat += "\n\n" 

    file = open("logs/statistics.log", "a", encoding="utf-8")
    file.write(textEstat)
    file.close()